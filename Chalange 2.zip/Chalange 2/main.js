var billpay = [{ bill:'Electricity', amount: 100, status: 'Paid'},
							   { bill:'Internet(Wi/fi)', amount: 100, status:'Due' },
							   { bill:'Parking Charges',  amount: 100, status:'Paid' },
							   { bill:'Phone', amount: 100, status:'Due'},
							   { bill:'House Tax', amount: 100, status:'Paid'}]; 

var SelectedDelete = null;
var SelectedDeleteArray = [];
var updateItemIndex = null;
var show = false;
var app = angular.module('App',[])
  .directive('tabMenu',[function(){
    return {
      restrict:'A',
      require: 'ngModel',                  
      scope: { modelValue: '=ngModel' },  // modelValue for $watch 
      link:function(scope, element, attr, ngModel){
          // Links collection
          var links=element.find('a');
        
          // Add click listeners
          links.on('click',function(e){
              e.preventDefault();
              ngModel.$setViewValue( angular.element(this).attr('href') );
              scope.$apply();
          })        

          // State handling (set active) on model change
          scope.$watch('modelValue',function(){
            for(var i=0,l=links.length;i<l;++i){
              var link = angular.element(links[i]);
              link.attr('href') === scope.modelValue ?
              link.parent().addClass('active') : link.parent().removeClass('active')
            }
          })
      }
    }
  }])
  .controller('AppCtrl',['$scope',function($scope){
    $scope.ui = {};
    $scope.ui.tabview = 'tab1.html';
  }])
.controller('billPayCtrl', ['$scope',function($scope){    
  $scope.billpay = billpay;
  $scope.addItem = function(){
    $scope.closeMode();
    var item = {
      bill: $scope.bill,
      status: $scope.status ? 'Paid' : 'Due',
      amount: $scope.amount
    };
    if(item.bill && item.amount) {
        if($scope.Operation === 'Add') {
            $scope.billpay.push(item); 
            $scope.Message = 'Bill Added Successfully!!!';
        } else {
            $scope.billpay[updateItemIndex].bill = item.bill;
            $scope.billpay[updateItemIndex].amount = item.amount;
            $scope.billpay[updateItemIndex].status = $scope.status ? 'Paid' : 'Due';
            $scope.Message = 'Bill updated successfully...!!!';
        }
        $('#myModal').modal("hide");
        $(".alert-success ").css("display","block"); 
    } else {
        alert("All * fields are required...");
    }
  };
  $scope.setDeleteIndex = function(index) {
    $scope.closeMode();
    SelectedDelete=index;
  };
  $scope.deleteItem = function() {
    $scope.closeMode();
    if(SelectedDelete!==null) {
        billpay.splice(SelectedDelete, 1);
        $('#myModalDelete').modal("hide");
        SelectedDelete = null;    
        $scope.Message = 'Bill deleted successfully...!!!';  
    } else {
        SelectedDeleteArray.sort(function(a, b){return b-a}).forEach(index => {
            billpay.splice(billpay.indexOf(index), 1);
        });
        $('#myModalDelete').modal("hide");
        SelectedDeleteArray=[];
        $scope.Message = 'Selected bills deleted successfully...!!!';
    }
    $(".alert-success ").css("display","block"); 
  };
  $scope.addInSelection = function(index) {
    $scope.closeMode();
    var Index = SelectedDeleteArray.indexOf(index);
    if(Index===-1) { 
        SelectedDeleteArray.push(index); 
    } else {
        SelectedDeleteArray.splice(Index, 1);
    }
    console.log(SelectedDeleteArray);
  };
  $scope.closeMode = function() {
    $(".alert-success ").css("display","none"); 
    $(".alert-danger ").css("display","none");
  };
  $scope.UpdateItem = function(item) {
    $scope.closeMode();
    $scope.bill = item.bill;
    $scope.amount = item.amount;
    $scope.status = item.status === 'Paid' ? true : false;
    $scope.Operation = 'Update';
    updateItemIndex = billpay.indexOf(item);
  };
  $scope.addItemData = function() {
    $scope.closeMode();
    $scope.Operation = 'Add';
    $scope.bill = '';
    $scope.amount = '';
    $scope.status = false;
  };
  $scope.deleteModal = function() {
    $scope.closeMode(); 
      if(SelectedDeleteArray.length===0) {
        $scope.Message = "Select bill...!!!";
        $(".alert-danger ").css("display","block"); 
      } else {
        $("#myModalDelete").modal("show");
      }
  };
}])
.controller('CheckFIBCtrl',['$scope', function($scope){  
    $scope.CheckFib = function() {
        if($scope.CheckNum) {
            var n = [1, 2];
            while (n[n.length-1] + n[n.length-2] <= $scope.CheckNum) {
                $scope.closeMode();
                n.push(n[n.length-1] + n[n.length-2]);
            }
            $scope.dataSet = n;
            if($scope.dataSet[$scope.dataSet.length-1] === $scope.CheckNum) {
                $scope.Message = $scope.CheckNum + " is a part of fibonacci series...";
                $(".alert-success ").css("display","block");
                $scope.myVar = "Found";
            } else {
                $scope.Message = $scope.CheckNum + " is not a part of fibonacci series...";
                $(".alert-danger ").css("display","block");
                $(".BivItem:last").css("background-color", "#103351!important");
            } 
        } else {
            $scope.Message = "Please enter something...";
            $(".alert-danger ").css("display","block");
            $scope.dataSet = [];
        }
    };
    $scope.closeMode = function() {
        $(".alert-success ").css("display","none"); 
        $(".alert-danger ").css("display","none");
    };
}]);  
